<script lang="ts">
	export let classNames = '';
</script>

<svg
	xmlns="http://www.w3.org/2000/svg"
	width="620"
	height="830"
	viewBox="0 0 620 830"
	class={classNames}
>
	<path
		id="_2960349"
		data-name="2960349"
		d="M590,0H30A30,30,0,0,0,0,30V800a30,30,0,0,0,30,30l560-60a30,30,0,0,0,30-30V30A30,30,0,0,0,590,0Z"
		fill="currentColor"
	/>
</svg>
