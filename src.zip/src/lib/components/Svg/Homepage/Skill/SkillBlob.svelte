<script lang="ts">
	export let classNames = '';
</script>

<svg
	xmlns="http://www.w3.org/2000/svg"
	xmlns:xlink="http://www.w3.org/1999/xlink"
	width="250.49"
	height="240.947"
	viewBox="0 0 250.49 240.947"
	class={classNames}
>
	<defs>
		<linearGradient
			id="linear-gradient"
			x1="0.929"
			y1="0.111"
			x2="0.263"
			y2="0.935"
			gradientUnits="objectBoundingBox"
		>
			<stop offset="0" stop-color="currentColor" />
			<stop offset="1" stop-color="currentColor" stop-opacity="0" />
		</linearGradient>
	</defs>
	<path
		id="Path_1423"
		data-name="Path 1423"
		d="M226.445,284.631c-7.363,10.259-10.457,22.867-15.316,34.52s-12.588,23.343-24.611,27.194c-12,3.848-25.153-1.186-35.508-8.377s-19.145-16.548-29.965-23.016c-11.941-7.138-25.731-10.4-39.254-13.665s-27.29-6.755-39-14.256S21.573,267.19,21.1,253.288c-.545-15.931,10.533-29.962,22.923-39.99s26.765-17.8,37.288-29.774c10.755-12.225,16.638-27.842,24.39-42.157S124.345,113,139.951,108.373c9.883-2.93,20.634-1.685,30.385,1.658s18.675,8.677,27.468,14.058c15.131,9.265,30.21,18.867,43.125,31.032s23.666,27.158,28.3,44.284,2.557,36.529-7.914,50.851C251.658,263.468,235.985,271.332,226.445,284.631Z"
		transform="translate(-21.078 -106.727)"
		fill="url(#linear-gradient)"
	/>
</svg>
