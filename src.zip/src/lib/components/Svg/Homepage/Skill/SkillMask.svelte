<script lang="ts">
	export let classNames = '';
</script>

<svg
	xmlns="http://www.w3.org/2000/svg"
	width="570"
	height="763"
	viewBox="0 0 570 763"
	class={classNames}
>
	<path
		id="_3108428"
		data-name="3108428"
		d="M30,0H540a30,30,0,0,1,30,30V678a30,30,0,0,1-30,30L30,763A30,30,0,0,1,0,733V30A30,30,0,0,1,30,0Z"
		fill="#fff"
	/>
</svg>
