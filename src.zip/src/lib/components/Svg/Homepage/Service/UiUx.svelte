<script lang="ts">
	export let classNames = '';
</script>

<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 63.931 63.93" class={classNames}>
	<g id="Group_1234" data-name="Group 1234" transform="translate(0 -0.005)">
		<g id="Group_1223" data-name="Group 1223" transform="translate(0 0.005)">
			<g id="Group_1222" data-name="Group 1222" transform="translate(0 0)">
				<path
					id="Path_1441"
					data-name="Path 1441"
					d="M60.712,3.224a11,11,0,0,0-15.548,0L.268,48.119,0,63.935l15.816-.268L60.711,18.772a10.995,10.995,0,0,0,0-15.548ZM14.74,61.128,2.6,61.334l.206-12.139L6.513,45.49,18.445,57.423Zm5.512-5.512L8.32,43.682,41.573,10.43,53.506,22.362ZM58.9,16.965l-3.59,3.59L43.381,8.623l3.591-3.591A8.437,8.437,0,1,1,58.9,16.965Z"
					transform="translate(0 -0.005)"
					fill="currentColor"
				/>
			</g>
		</g>
		<g id="Group_1225" data-name="Group 1225" transform="translate(31.078 29.245)">
			<g id="Group_1224" data-name="Group 1224" transform="translate(0 0)">
				<rect
					id="Rectangle_2423"
					data-name="Rectangle 2423"
					width="2.556"
					height="2.556"
					transform="translate(0 1.808) rotate(-45)"
					fill="currentColor"
				/>
			</g>
		</g>
		<g id="Group_1227" data-name="Group 1227" transform="translate(35.777 24.545)">
			<g id="Group_1226" data-name="Group 1226" transform="translate(0 0)">
				<rect
					id="Rectangle_2424"
					data-name="Rectangle 2424"
					width="2.556"
					height="2.556"
					transform="translate(0 1.808) rotate(-45)"
					fill="currentColor"
				/>
			</g>
		</g>
		<g id="Group_1229" data-name="Group 1229" transform="translate(26.376 33.945)">
			<g id="Group_1228" data-name="Group 1228" transform="translate(0 0)">
				<rect
					id="Rectangle_2425"
					data-name="Rectangle 2425"
					width="2.556"
					height="2.556"
					transform="translate(0 1.808) rotate(-45)"
					fill="currentColor"
				/>
			</g>
		</g>
		<g id="Group_1231" data-name="Group 1231" transform="translate(21.717 38.644)">
			<g id="Group_1230" data-name="Group 1230" transform="translate(0 0)">
				<rect
					id="Rectangle_2426"
					data-name="Rectangle 2426"
					width="2.497"
					height="2.556"
					transform="translate(0 1.766) rotate(-45)"
					fill="currentColor"
				/>
			</g>
		</g>
		<g id="Group_1233" data-name="Group 1233" transform="translate(30.555 61.357)">
			<g id="Group_1232" data-name="Group 1232">
				<rect
					id="Rectangle_2427"
					data-name="Rectangle 2427"
					width="32.095"
					height="2.556"
					fill="currentColor"
				/>
			</g>
		</g>
	</g>
</svg>
