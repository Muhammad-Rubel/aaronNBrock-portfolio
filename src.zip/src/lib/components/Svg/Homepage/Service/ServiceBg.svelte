<script lang="ts">
	export let classNames = '';
</script>

<!-- #f1f6f9 -->
<svg viewBox="0 0 1283 1126" class={classNames}
	><path
		fill="currentColor"
		d="M1e2.0h1183v1126l-1183-80A1e2 1e2.0 010 946V1e2A1e2 1e2.0 011e2.0z"
		data-name="Path 1369"
	/></svg
>
