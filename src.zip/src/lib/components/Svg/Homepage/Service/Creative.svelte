<script lang="ts">
	export let classNames = '';
</script>

<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 65.313 63.93" class={classNames || 'h-16'}>
	<g id="Group_1221" data-name="Group 1221" transform="translate(0 -5.356)">
		<g id="Group_1216" data-name="Group 1216" transform="translate(0 5.356)">
			<g id="Group_1215" data-name="Group 1215" transform="translate(0 0)">
				<path
					id="Path_1438"
					data-name="Path 1438"
					d="M32.656,5.356,0,24.158l32.656,18.8,32.657-18.8ZM5.093,24.158,32.656,8.288,60.22,24.158,32.656,40.028Z"
					transform="translate(0 -5.356)"
					fill="currentColor"
				/>
			</g>
		</g>
		<g id="Group_1218" data-name="Group 1218" transform="translate(1.912 36.22)">
			<g id="Group_1217" data-name="Group 1217">
				<path
					id="Path_1439"
					data-name="Path 1439"
					d="M75.037,244.49,45.56,261.461,16.085,244.49l-1.268,2.2,30.743,17.7,30.745-17.7Z"
					transform="translate(-14.817 -244.49)"
					fill="currentColor"
				/>
			</g>
		</g>
		<g id="Group_1220" data-name="Group 1220" transform="translate(1.912 49.383)">
			<g id="Group_1219" data-name="Group 1219">
				<path
					id="Path_1440"
					data-name="Path 1440"
					d="M75.037,346.481,45.56,363.452,16.085,346.481l-1.268,2.2,30.743,17.7,30.745-17.7Z"
					transform="translate(-14.817 -346.481)"
					fill="currentColor"
				/>
			</g>
		</g>
	</g>
</svg>
