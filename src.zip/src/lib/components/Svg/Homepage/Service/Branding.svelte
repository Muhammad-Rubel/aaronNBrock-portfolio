<script lang="ts">
	export let classNames = '';
</script>

<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 62.786 63.93" class={classNames || 'h-16'}>
	<g
		id="_101-hierarchical-structure_1_"
		data-name="101-hierarchical-structure (1)"
		transform="translate(-4.404)"
	>
		<g id="Group_1235" data-name="Group 1235" transform="translate(4.404)">
			<path
				id="Path_1442"
				data-name="Path 1442"
				d="M60.4,47.8V39.376H37.076V28.721a14.392,14.392,0,1,0-2.557,0V39.376H11.19V47.8H4.4V63.93h16.13V47.8H13.748V41.933H34.519V47.8H27.732V63.93h16.13V47.8H37.076V41.933H57.847V47.8H51.06V63.93H67.19V47.8ZM17.977,50.357V61.373H6.961V50.357Zm23.328,0V61.373H30.289V50.357ZM35.8,26.229A11.836,11.836,0,1,1,47.633,14.393,11.849,11.849,0,0,1,35.8,26.229ZM64.633,61.373H53.618V50.357H64.633Z"
				transform="translate(-4.404)"
				fill="currentColor"
			/>
		</g>
	</g>
</svg>
