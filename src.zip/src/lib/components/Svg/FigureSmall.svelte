<script lang="ts">
	export let classNames = '';
</script>

<!-- #282f49 -->
<svg
	xmlns="http://www.w3.org/2000/svg"
	width="120"
	height="120"
	viewBox="0 0 120 120"
	class={classNames}
>
	<g id="Group_1203" data-name="Group 1203" transform="translate(-384 -1392)">
		<rect
			id="Rectangle_2206"
			data-name="Rectangle 2206"
			width="12"
			height="2"
			rx="1"
			transform="translate(391 1392) rotate(90)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2271"
			data-name="Rectangle 2271"
			width="12"
			height="2"
			rx="1"
			transform="translate(391 1500) rotate(90)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2238"
			data-name="Rectangle 2238"
			width="12"
			height="2"
			rx="1"
			transform="translate(391 1446) rotate(90)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2222"
			data-name="Rectangle 2222"
			width="12"
			height="2"
			rx="1"
			transform="translate(391 1419) rotate(90)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2241"
			data-name="Rectangle 2241"
			width="12"
			height="2"
			rx="1"
			transform="translate(391 1473) rotate(90)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2214"
			data-name="Rectangle 2214"
			width="12"
			height="2"
			rx="1"
			transform="translate(499 1392) rotate(90)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2289"
			data-name="Rectangle 2289"
			width="12"
			height="2"
			rx="1"
			transform="translate(499 1500) rotate(90)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2256"
			data-name="Rectangle 2256"
			width="12"
			height="2"
			rx="1"
			transform="translate(499 1446) rotate(90)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2231"
			data-name="Rectangle 2231"
			width="12"
			height="2"
			rx="1"
			transform="translate(499 1419) rotate(90)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2257"
			data-name="Rectangle 2257"
			width="12"
			height="2"
			rx="1"
			transform="translate(499 1473) rotate(90)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2210"
			data-name="Rectangle 2210"
			width="12"
			height="2"
			rx="1"
			transform="translate(445 1392) rotate(90)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2279"
			data-name="Rectangle 2279"
			width="12"
			height="2"
			rx="1"
			transform="translate(445 1500) rotate(90)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2248"
			data-name="Rectangle 2248"
			width="12"
			height="2"
			rx="1"
			transform="translate(445 1446) rotate(90)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2226"
			data-name="Rectangle 2226"
			width="12"
			height="2"
			rx="1"
			transform="translate(445 1419) rotate(90)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2249"
			data-name="Rectangle 2249"
			width="12"
			height="2"
			rx="1"
			transform="translate(445 1473) rotate(90)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2209"
			data-name="Rectangle 2209"
			width="12"
			height="2"
			rx="1"
			transform="translate(418 1392) rotate(90)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2273"
			data-name="Rectangle 2273"
			width="12"
			height="2"
			rx="1"
			transform="translate(418 1500) rotate(90)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2242"
			data-name="Rectangle 2242"
			width="12"
			height="2"
			rx="1"
			transform="translate(418 1446) rotate(90)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2223"
			data-name="Rectangle 2223"
			width="12"
			height="2"
			rx="1"
			transform="translate(418 1419) rotate(90)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2243"
			data-name="Rectangle 2243"
			width="12"
			height="2"
			rx="1"
			transform="translate(418 1473) rotate(90)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2211"
			data-name="Rectangle 2211"
			width="12"
			height="2"
			rx="1"
			transform="translate(472 1392) rotate(90)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2295"
			data-name="Rectangle 2295"
			width="12"
			height="2"
			rx="1"
			transform="translate(472 1500) rotate(90)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2250"
			data-name="Rectangle 2250"
			width="12"
			height="2"
			rx="1"
			transform="translate(472 1446) rotate(90)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2227"
			data-name="Rectangle 2227"
			width="12"
			height="2"
			rx="1"
			transform="translate(472 1419) rotate(90)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2251"
			data-name="Rectangle 2251"
			width="12"
			height="2"
			rx="1"
			transform="translate(472 1473) rotate(90)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2207"
			data-name="Rectangle 2207"
			width="12"
			height="2"
			rx="1"
			transform="translate(396 1399) rotate(-180)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2270"
			data-name="Rectangle 2270"
			width="12"
			height="2"
			rx="1"
			transform="translate(396 1507) rotate(-180)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2239"
			data-name="Rectangle 2239"
			width="12"
			height="2"
			rx="1"
			transform="translate(396 1453) rotate(-180)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2224"
			data-name="Rectangle 2224"
			width="12"
			height="2"
			rx="1"
			transform="translate(396 1426) rotate(-180)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2244"
			data-name="Rectangle 2244"
			width="12"
			height="2"
			rx="1"
			transform="translate(396 1480) rotate(-180)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2215"
			data-name="Rectangle 2215"
			width="12"
			height="2"
			rx="1"
			transform="translate(504 1399) rotate(-180)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2300"
			data-name="Rectangle 2300"
			width="12"
			height="2"
			rx="1"
			transform="translate(504 1507) rotate(-180)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2252"
			data-name="Rectangle 2252"
			width="12"
			height="2"
			rx="1"
			transform="translate(504 1453) rotate(-180)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2228"
			data-name="Rectangle 2228"
			width="12"
			height="2"
			rx="1"
			transform="translate(504 1426) rotate(-180)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2253"
			data-name="Rectangle 2253"
			width="12"
			height="2"
			rx="1"
			transform="translate(504 1480) rotate(-180)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2212"
			data-name="Rectangle 2212"
			width="12"
			height="2"
			rx="1"
			transform="translate(450 1399) rotate(-180)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2284"
			data-name="Rectangle 2284"
			width="12"
			height="2"
			rx="1"
			transform="translate(450 1507) rotate(-180)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2245"
			data-name="Rectangle 2245"
			width="12"
			height="2"
			rx="1"
			transform="translate(450 1453) rotate(-180)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2229"
			data-name="Rectangle 2229"
			width="12"
			height="2"
			rx="1"
			transform="translate(450 1426) rotate(-180)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2246"
			data-name="Rectangle 2246"
			width="12"
			height="2"
			rx="1"
			transform="translate(450 1480) rotate(-180)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2208"
			data-name="Rectangle 2208"
			width="12"
			height="2"
			rx="1"
			transform="translate(423 1399) rotate(-180)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2276"
			data-name="Rectangle 2276"
			width="12"
			height="2"
			rx="1"
			transform="translate(423 1507) rotate(-180)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2240"
			data-name="Rectangle 2240"
			width="12"
			height="2"
			rx="1"
			transform="translate(423 1453) rotate(-180)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2225"
			data-name="Rectangle 2225"
			width="12"
			height="2"
			rx="1"
			transform="translate(423 1426) rotate(-180)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2247"
			data-name="Rectangle 2247"
			width="12"
			height="2"
			rx="1"
			transform="translate(423 1480) rotate(-180)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2213"
			data-name="Rectangle 2213"
			width="12"
			height="2"
			rx="1"
			transform="translate(477 1399) rotate(-180)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2306"
			data-name="Rectangle 2306"
			width="12"
			height="2"
			rx="1"
			transform="translate(477 1507) rotate(-180)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2254"
			data-name="Rectangle 2254"
			width="12"
			height="2"
			rx="1"
			transform="translate(477 1453) rotate(-180)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2230"
			data-name="Rectangle 2230"
			width="12"
			height="2"
			rx="1"
			transform="translate(477 1426) rotate(-180)"
			fill="currentColor"
		/>
		<rect
			id="Rectangle_2255"
			data-name="Rectangle 2255"
			width="12"
			height="2"
			rx="1"
			transform="translate(477 1480) rotate(-180)"
			fill="currentColor"
		/>
	</g>
</svg>
