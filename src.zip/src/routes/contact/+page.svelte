<script lang="ts">
	import ContactForm from '$lib/components/Contact/ContactForm.svelte';
	import ContactOptions from '$lib/components/Contact/ContactOptions.svelte';
</script>

<div class="pt-32 overflow-hidden">
	<!-- section One -->
	<ContactOptions />

	<!-- section Two -->
	<ContactForm />
</div>
