<script>
	import About from '$lib/components/Homepage/About.svelte';
	import Blog from '$lib/components/Homepage/Blog.svelte';
	import Hero from '$lib/components/Homepage/Hero.svelte';
	import Portfolio from '$lib/components/Homepage/Portfolio.svelte';
	import Resume from '$lib/components/Homepage/Resume.svelte';
	import Services from '$lib/components/Homepage/Services.svelte';
	import Skillset from '$lib/components/Homepage/Skillset.svelte';
	import Testimonial from '$lib/components/Homepage/Testimonial.svelte';
</script>

<Hero />
<About />
<Services />
<Portfolio />
<Resume />
<Skillset />
<Testimonial />
<Blog />
